function realExp = Exponentielle( lambda )

    U=rand(1,1);

    int=-log(1-U);
    realExp=int/lambda;

end

