function simInv = Inversion()

    U=rand(1,1);

    int=sqrt(U)*log(2);
    simInv=exp(int)-1;


end

